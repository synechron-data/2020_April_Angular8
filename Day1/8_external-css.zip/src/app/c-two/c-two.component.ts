import { Component } from "@angular/core";

@Component({
    selector: 'c-two',
    styleUrls: ['./c-two.component.css'],
    template: `
        <div class="container">
            <h1 class="text-success">Hello from Component Two!</h1>
            <h2 class="card">From Component Two!</h2>
        </div>
    `
})
export class CTwoComponent {

}