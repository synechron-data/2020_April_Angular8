import { NgModule, APP_BOOTSTRAP_LISTENER, ComponentRef } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { RootComponent } from "./root.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

// Component Imports
import { ListComponent } from "./list/list.component";
import { ShowCaptionPipe } from "./pipes/caption.pipe";
import { CapitalizePipe } from "./pipes/capitalize.pipe";
import { FilterPipe } from "./pipes/filter.pipe";

@NgModule({
    imports: [BrowserModule, FormsModule, ReactiveFormsModule],
    declarations: [RootComponent, ListComponent, ShowCaptionPipe, CapitalizePipe, FilterPipe],
    bootstrap: [RootComponent],
    providers: [{
        provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
            return (component: ComponentRef<any>) => {
                console.log(component);
            }
        }
    }]
})
export class AppModule {

}