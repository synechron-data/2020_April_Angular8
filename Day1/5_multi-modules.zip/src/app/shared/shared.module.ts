import { NgModule } from "@angular/core";
import { SharedComponent } from "./s-com.component";

@NgModule({
    declarations: [SharedComponent],
    exports: [SharedComponent]
})
export class SharedModule {

}