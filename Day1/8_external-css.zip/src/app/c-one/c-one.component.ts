import { Component } from "@angular/core";

@Component({
    selector: 'c-one',
    styleUrls: ['./c-one.component.css'],
    template: `
        <div class="container">
            <h1 class="text-info">Hello from Component One!</h1>
            <h2 class="card">From Component One!</h2>
        </div>
    `
})
export class COneComponent {

}