import { Component } from "@angular/core";

@Component({
    selector: 'hello',
    template: `
        <h1>Hello World!</h1>
    `
})
export class HelloComponent {

}