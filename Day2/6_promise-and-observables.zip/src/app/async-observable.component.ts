import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable, interval, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
    selector: 'async-observable',
    template: `
        <h2 class="text-info">With Observable</h2>
        <h3>Result: {{observableData}}</h3>
        <h3>Observable Result: {{observableResult | async}}</h3>
    `
})

export class AsyncObservableComponent implements OnInit, OnDestroy {
    observableData: number;
    observableResult: Observable<number>;

    sOne:Subscription;

    constructor() { }
    
    ngOnDestroy(): void {
        this.sOne.unsubscribe();
    }

    ngOnInit() {
        this.sOne = this.getObservable().subscribe(n => this.observableData = n);
        this.observableResult = this.getObservable();
    }

    getObservable(): Observable<number> {
        return interval(2000).pipe(map(v => Math.random()));
    }
}