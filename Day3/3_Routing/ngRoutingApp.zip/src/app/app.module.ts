import { NgModule, APP_BOOTSTRAP_LISTENER, ComponentRef } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { RouterModule } from "@angular/router";
import { APP_BASE_HREF } from "@angular/common";

import { AuthorsModule } from "./authors-module/authors.module";

import { RootComponent } from "./components/root/root.component";
import { BSNavigationComponent } from "./components/bs-nav/bs-nav.component";
import { HomeComponent } from "./components/home/home.component";
import { AboutComponent } from "./components/about/about.component";
import { NotFoundComponent } from "./components/not-found/not-found.component";

import { routes } from "./app.routes";
import { ProductsComponent } from "./components/products/products.component";
import { ProductDetailsComponent } from "./components/products/pd.component";
import { ProductNotSelectedComponent } from "./components/products/ns.component";
import { AdminComponent } from "./components/admin/admin.component";
import { TokenInterceptor } from "./services/token-interceptor.service";
import { AuthenticationService } from "./services/authentication.service";
import { AuthGuardService } from "./services/auth-guard.service";
import { LoginComponent } from "./components/login/login.component";


@NgModule({
    imports: [BrowserModule, FormsModule, ReactiveFormsModule, HttpClientModule, RouterModule.forRoot(routes), AuthorsModule],
    declarations: [RootComponent, BSNavigationComponent, HomeComponent, AboutComponent, NotFoundComponent,
        ProductsComponent, ProductDetailsComponent, ProductNotSelectedComponent,
        AdminComponent, LoginComponent],
    bootstrap: [RootComponent],
    providers: [
        AuthenticationService,
        AuthGuardService,
        {
            provide: APP_BASE_HREF,
            useValue: '/'
        },
        {
            provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
                return (component: ComponentRef<any>) => {
                    console.log(component);
                }
            }
        },
        {
            provide: HTTP_INTERCEPTORS,
            multi: true,
            useClass: TokenInterceptor
        }
    ]
})
export class AppModule {

}