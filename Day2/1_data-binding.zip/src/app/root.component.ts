import { Component, AfterViewInit, NgZone } from "@angular/core";

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Data Binding</h1>
            </div>

            <div [hidden]=flag>
                <assign-one></assign-one>
            <div>

            <div [hidden]=flag>
                <assign-two></assign-two>
            <div>

            <div [hidden]=!flag>
                <h2 class="text-success">Two Way Binding</h2>
                <input type="text" [value]="message" />
                <br/>
                <input type="text" bindon-ngModel="message" />
                <br/>
                <input type="text" [(ngModel)]="message" />
                <br/>
                <input type="text" [ngModel]="message" (ngModelChange)="message = $event"/>
                <br/>
                <input type="text" [(ngModel)]="message" [ngModelOptions]="{updateOn:'blur'}"/>
                <h2>Message: {{message}}</h2>
                <br/> <br/>
                <input type="text" [(ngModel)]="name" />
                <h2>Name is: {{name}}</h2>
                <br/> <br/>
                <input type="text" [(ngModel)]="city" (change)="doUpdate(city)"/>
                <input type="text" [(ngModel)]="city" (input)="doUpdate(city)"/>
                <h2>Message: {{message}}</h2>
            </div>

            <div [hidden]=!flag>
                <h2 class="text-success">Event Binding</h2>
                <h2>Message: {{message}}</h2>
                <button class="btn btn-info" on-click="doChange()">Click</button>
                <button class="btn btn-info" (click)="doChange()">Click</button>
                <button class="btn btn-info" id="btnJS">Click - JS</button>
            </div>

            <div [hidden]=!flag>
                <h2 class="text-success">Attribute Binding</h2>
                <img [src]="imageSource" [height]="h" [width]="w" />
                <table style="border: 1px solid black" [attr.height]="h" [attr.width]="w">
                    <tr>
                        <th>Firstname</th>
                        <th>Lastname</th>
                        <th>Age</th>
                    </tr>
                    <tr>
                        <td>Jill</td>
                        <td>Smith</td>
                        <td>50</td>
                    </tr>
                    <tr>
                        <td>Eve</td>
                        <td>Jackson</td>
                        <td>94</td>
                    </tr>
                </table>
            </div>

            <div [hidden]=!flag>
                <h2 class="text-success">Property Binding</h2>
                <h2>Message: {{message}}</h2>
                <h2 innerHTML={{message}}>Message: </h2>
                <h2>Message: <span innerHTML={{message}}></span></h2>
                <h2 bind-innerHTML=message>Message: </h2>
                <h2 [innerHTML]=message>Message: </h2>

                <h2>Hiding: <span hidden={{flag}}>{{message}}</span></h2>
                <h2>Hiding: <span bind-hidden=flag>{{message}}</span></h2>
                <h2>Hiding: <span [hidden]=flag>{{message}}</span></h2>
            </div>
        </div>
    `
})
export class RootComponent implements AfterViewInit {
    message: string;
    flag: boolean;
    imageSource: any;
    h: number;
    w: number;

    constructor(private ngZone: NgZone) {
        this.message = "Hello World!";
        this.flag = false;
        this.imageSource = require('../assets/image1.jpg');
        this.h = 300;
        this.w = 300;
    }

    ngAfterViewInit(): void {
        this.ngZone.runOutsideAngular(() => {
            document.getElementById("btnJS").addEventListener("click", () => {
                this.message = new Date().toTimeString();
                console.log(this.message);
            });
        });

        // document.getElementById("btnJS").addEventListener("click", () => {
        //     this.message = new Date().toTimeString();
        // });
    }

    doChange() {
        this.message = new Date().toTimeString();
    }

    doUpdate(city:string){
        this.message = `You are from ${city}`;
    }
}