import { Component, OnInit, OnDestroy } from '@angular/core';

import { Post } from './models/post.model';
import { Subscription } from 'rxjs';
import { PostService } from './services/post.service';

@Component({
    selector: 'root',
    templateUrl: 'root.component.html',
    providers: [PostService]
})

export class RootComponent implements OnInit, OnDestroy {
    posts: Array<Post>;
    message: string;
    get_sub: Subscription;

    constructor(private pService: PostService) {
        this.message = "Loading Data, please wait...";
    }

    ngOnInit() {
        this.get_sub = this.pService.getPosts().subscribe((resData) => {
            this.posts = resData;
            this.message = "";
        }, (err: string) => {
            this.message = err;
        });
    }

    ngOnDestroy(): void {
        this.get_sub.unsubscribe();
    }
}

// ---------------------------------------------------------------------------------

// import { Component, OnInit, OnDestroy } from '@angular/core';
// import { HttpClient, HttpErrorResponse } from "@angular/common/http";

// import { Post } from './models/post.model';
// import { Subscription } from 'rxjs';

// @Component({
//     selector: 'root',
//     templateUrl: 'root.component.html'
// })

// export class RootComponent implements OnInit, OnDestroy {
//     posts: Array<Post>;
//     message: string;
//     url: string;
//     get_sub: Subscription;

//     constructor(private httpClient: HttpClient) {
//         this.url = "https://jsonplaceholder.typicode.com/posts";
//         this.message = "Loading Data, please wait...";
//     }

//     ngOnInit() {
//         this.get_sub = this.httpClient.get<Array<Post>>(this.url).subscribe((resData) => {
//             this.posts = resData;
//             this.message = "";
//         }, (err: HttpErrorResponse) => {
//             this.message = err.message;
//         });
//     }

//     ngOnDestroy(): void {
//         this.get_sub.unsubscribe();
//     }
// }