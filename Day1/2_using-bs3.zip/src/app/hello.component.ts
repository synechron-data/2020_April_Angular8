import { Component } from "@angular/core";

@Component({
    selector: 'hello',
    template: `
        <div class="container">
            <h1 class="text-success">Hello World!</h1>
        </div>
    `
})
export class HelloComponent {

}