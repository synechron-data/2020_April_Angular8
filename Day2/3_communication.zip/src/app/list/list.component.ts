import { Component, OnInit, Input } from '@angular/core';

@Component({
    selector: 'list',
    templateUrl: 'list.component.html'
})

export class ListComponent implements OnInit {
    selected: string;

    @Input() personList: Array<string>;

    constructor() {
    }

    ngOnInit() { }

    select(p: string, e: Event) {
        e.preventDefault();
        this.selected = p;
    }
}